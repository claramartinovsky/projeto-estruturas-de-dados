package estruturas;

public class Pilha {
    private String[] dados;
    private int topo;

    public Pilha(int capacidade) {
        dados = new String[capacidade];
        topo = -1;
    }

    public void empilhar(String valor) {
        if (topo == dados.length - 1) {  
            System.out.println("Pilha cheia! Nao e possivel empilhar: " + valor);
            return;
        }
        dados[++topo] = valor;
    }

    public String desempilhar() {
        if (estaVazia()) {
            System.out.println("Pilha vazia! Nao a possivel desempilhar.");
            return null;
        }
        return dados[topo--];
    }

    public boolean estaVazia() {
        return topo == -1;
    }

    public int capacidade() {
        return dados.length;
    }
}

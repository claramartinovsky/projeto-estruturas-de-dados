package estruturas;

public class Main {
    public static void main(String[] args) {
        System.out.println("===== Editor de Texto =====");
        EditorTexto editor = new EditorTexto(10);
        editor.inserirTexto("Uma vez");
        editor.inserirTexto("Duas vezes");
        editor.desfazer();
        editor.refazer();
        editor.inserirTexto("Tres vezes");
        editor.desfazer();
        editor.desfazer();
    }
}

